# Glow Top-Up

Boutique locale React/Vite avec une API Express locale. Elle ne contient ni Supabase, ni clés client, ni paiement réel.

## Démarrer

1. Copiez `.env.example` vers `.env` et complétez uniquement les paramètres validés par vos prestataires.
2. `npm install`
3. `npm run dev` puis ouvrez `http://localhost:5173`.
4. `npm run check` et `npm run build` pour vérifier le projet.

## Données commerciales

Modifiez `src/catalog.ts`. Les 25 catégories ont volontairement `providerCost: null` et affichent « Prix à confirmer » : aucun coût FazerCards ni frais MonCash n’a été inventé. Renseignez un prix seulement après avoir reçu le tarif fournisseur applicable, et conservez une trace de sa date et de sa région.

Le prix cible est :

`(coût fournisseur + frais fixes) / (1 - frais de paiement - 0,15)`

Cette formule produit une marge brute cible de 15 % du prix de vente après les frais renseignés. Arrondissez selon votre politique commerciale, puis vérifiez la marge sur le prix arrondi.

## Intégrations et sécurité

- Ne placez jamais une clé dans `VITE_*`, le catalogue frontend ou un dépôt public.
- Ajoutez les identifiants MonCash/FazerCards uniquement à `.env` côté serveur après réception des contrats et de la documentation actuelle.
- Implémentez les appels fournisseur, les signatures de webhook, l’idempotence, le journal d’audit et la vérification de paiement dans `server/`.
- La route `POST /api/orders` refuse actuellement toute commande (503) : elle ne peut pas débiter ni livrer.
- L’API accepte uniquement l’origine locale configurée par `ALLOWED_ORIGIN`.

## Visuels

Les cartes utilisent volontairement des illustrations de remplacement marquées « non officielle ». Avant publication, obtenez des assets sous licence/autorisation (par exemple kit presse du détenteur) et gardez leur preuve de licence. Ne présentez pas un visuel générique comme officiel.

## À finaliser avant production

Mentions légales et coordonnées de l’entreprise, politique de confidentialité et remboursement validées pour la juridiction concernée, canal support, prix/régions/stock fournisseur, contrat et tarifs du prestataire de paiement, HTTPS, base de données locale sécurisée, observabilité, tests de paiement en bac à sable, protection anti-abus et procédure de rapprochement.
