export type Product = { id: string; category: string; title: string; description: string; providerCost: number | null; currency: 'HTG' | 'USD'; fixedCost: number; paymentRate: number; imageLabel: string };

// Editable commercial data. A null providerCost means that the item cannot be sold
// until an approved supplier quote is entered. Fees shown here are examples only.
export const catalog: Product[] = [
  ['free-fire','Free Fire','Diamants','Identifiant joueur requis'], ['mobile-legends','Mobile Legends','Diamants','ID et serveur requis'], ['pubg-mobile','PUBG Mobile','UC','Identifiant joueur requis'], ['call-of-duty-mobile','Call of Duty Mobile','CP','UID requis'], ['genshin-impact','Genshin Impact','Cristaux','UID requis'], ['roblox','Roblox','Robux','Nom d’utilisateur requis'], ['fortnite','Fortnite','V-Bucks','Compte/plateforme à confirmer'], ['valorant','VALORANT','Points','Riot ID requis'], ['league-of-legends','League of Legends','RP','Riot ID requis'], ['steam','Steam','Carte cadeau','Région à confirmer'], ['playstation','PlayStation','Carte cadeau','Région à confirmer'], ['xbox','Xbox','Carte cadeau','Région à confirmer'], ['nintendo','Nintendo','eShop','Région à confirmer'], ['google-play','Google Play','Carte cadeau','Région à confirmer'], ['apple','Apple','Carte cadeau','Région à confirmer'], ['netflix','Netflix','Abonnement/carte','Disponibilité locale à confirmer'], ['spotify','Spotify','Abonnement/carte','Disponibilité locale à confirmer'], ['discord','Discord','Nitro','Nom du compte requis'], ['twitch','Twitch','Bits','Nom du compte requis'], ['ea','EA','EA FC Points','Compte EA requis'], ['fc-mobile','EA FC Mobile','Points','UID requis'], ['brawl-stars','Brawl Stars','Gemmes','Supercell ID requis'], ['clash-of-clans','Clash of Clans','Pass / gemmes','Supercell ID requis'], ['clash-royale','Clash Royale','Pass / gemmes','Supercell ID requis'], ['honor-of-kings','Honor of Kings','Tokens','UID requis']].map(([id, category, title, description]) => ({
  id, category, title, description, providerCost: null, currency: 'HTG' as const, fixedCost: 0, paymentRate: 0, imageLabel: `Illustration ${category} — non officielle`
}));

export function priceFor(cost: number, fixedCost: number, paymentRate: number, margin = 0.15) {
  if (cost < 0 || fixedCost < 0 || paymentRate < 0 || margin < 0 || paymentRate + margin >= 1) return null;
  return (cost + fixedCost) / (1 - paymentRate - margin);
}
