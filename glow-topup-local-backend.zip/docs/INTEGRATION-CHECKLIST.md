# Checklist d’intégration

## Fournisseur (dont FazerCards si retenu)

- Obtenir la documentation officielle, les produits, les devises, les régions et les prix contractuels.
- Vérifier le mode sandbox, les limites, l’authentification et la politique de remboursement.
- Mapper chaque produit dans `src/catalog.ts` avec un coût daté et une disponibilité vérifiée.
- Ne jamais envoyer de mot de passe de joueur ; limiter les données à l’identifiant requis.

## Paiement (dont MonCash si retenu)

- Obtenir les tarifs effectifs, documentation officielle et accès sandbox.
- Conserver les secrets dans `.env` côté serveur ou un coffre de secrets en production.
- Créer une commande locale « en attente », demander le paiement côté serveur, puis valider la signature webhook avant livraison.
- Utiliser une clé d’idempotence et refuser toute seconde livraison de la même commande.

## Publication

- Remplacer les placeholders uniquement par des assets autorisés.
- Ajouter l’adresse légale, l’email de support, les délais confirmés et les politiques relues.
- Tester les cas : paiement refusé, webhook doublé, UID erroné, rupture fournisseur, remboursement, région non compatible.
