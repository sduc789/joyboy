import 'dotenv/config';
import cors from 'cors';
import express, { type Request, type Response } from 'express';

const app = express();
const origin = process.env.ALLOWED_ORIGIN ?? 'http://localhost:5173';
app.use(cors({ origin }));
app.use(express.json({ limit: '20kb' }));

app.get('/api/health', (_req: Request, res: Response) => res.json({ ok: true, service: 'glow-topup-api' }));

// Payment and supplier calls intentionally stay server-side. This endpoint is only
// a safe placeholder until documented provider credentials and webhook contracts exist.
app.post('/api/orders', (req: Request, res: Response) => {
  const { productId, playerId, region } = req.body as Record<string, unknown>;
  if (typeof productId !== 'string' || typeof playerId !== 'string' || typeof region !== 'string') {
    return res.status(400).json({ error: 'productId, playerId and region are required.' });
  }
  return res.status(503).json({ error: 'Ordering is not enabled. Configure an approved supplier and payment provider first.' });
});

const port = Number(process.env.PORT ?? 8787);
app.listen(port, () => console.log(`Glow API listening on ${port}`));
